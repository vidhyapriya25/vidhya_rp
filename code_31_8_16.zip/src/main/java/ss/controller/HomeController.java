package ss.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import ss.DAO.UserDAO;
import ss.Model.User;

	@Controller
	public class HomeController

	{
		static AnnotationConfigApplicationContext ct;
		static UserDAO us;
		
		
		static{
		ct =new  AnnotationConfigApplicationContext();
		ct.scan("ss");
		ct.refresh();
		us=(UserDAO) ct.getBean("userDAO");
		
		}
		
		@ModelAttribute("obj")
		public User getobj()
		{
			return new User();
		}
		
		
		
	@RequestMapping(value="/")
	public String gohome ()
	{
		return "index";	
	}

	@RequestMapping(value="/register")
	public String register()
	{
		return "register";
		
	}
	

	@RequestMapping(value="/AdminLogin")
	public String adminlogin()
			
	{
		
		return "adminaccount";
		
	}
	
	@RequestMapping(value="/UserLogin")
	public String userlogin(@ModelAttribute("obj")User user)
	{
		us.saveOrUpdate(user);
		return "useraccount";
	}

	@RequestMapping(value="/contact")
	public String contact()
	{
		return "contact";
	}
	
	

	}

