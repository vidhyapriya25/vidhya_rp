package ss.DAO;

import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.Admin;

@Repository("adminDAO")

public class AdminDAOImpl {
	@Autowired
	private SessionFactory sessionFactory;


	public AdminDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public AdminDAOImpl(){}


	
	public void saveOrUpdate(Admin admin) {
		sessionFactory.getCurrentSession().saveOrUpdate(admin);
			
	}

	
	public void delete(String id) {
		Admin admin = new Admin();
		admin.setId(id);
		sessionFactory.getCurrentSession().delete(admin);
	}

	
	public Admin get(String id) {
		String hql = "from admin where id=" + "'"+ id +"'";
		//  from user where id = '101'
		Query query =  sessionFactory.getCurrentSession().createQuery(hql);
		List<Admin> listAdmin = (List<Admin>) query.list();
		
		if (listAdmin != null && !listAdmin.isEmpty()) {
			return listAdmin.get(0);
		}
		return null;
	}
	
	
	public List<Admin> list() {
		@SuppressWarnings("unchecked")
		List<Admin> listAdmin = (List<Admin>) 
		          sessionFactory.getCurrentSession()
				.createCriteria(Admin.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listAdmin;
	}



	public void saverOrUpdate(Admin user) {
		// TODO Auto-generated method stub
		
	}

	
	public boolean isValidUser(String email_id,String password) {
		
		String hql="from admin where email_id='"+email_id+"'and password='"+password +"'";
		Query q= sessionFactory.getCurrentSession().createQuery(hql);
		List list= q.list();
		return (!list.isEmpty());
		
		
	}

	
	

}
