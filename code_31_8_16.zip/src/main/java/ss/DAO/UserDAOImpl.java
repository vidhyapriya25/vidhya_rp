package ss.DAO;

import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.User;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO {
	
	
	
		

		@Autowired
		private SessionFactory sessionFactory;


		public UserDAOImpl(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}



		
		public void saveOrUpdate(User user) {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
				
		}

		
		public void delete(int id) {
			User user = new User();
			user.setId(id);
			sessionFactory.getCurrentSession().delete(user);
		}

		
		public User get(int id) {
			/*String hql = "from User where id=" + "'"+ id +"'";
			//  from user where id = '101'
			Query query =  sessionFactory.getCurrentSession().createQuery(hql);
			List<User> listUser = (List<User>) query.list();
			
			if (listUser != null && !listUser.isEmpty()) {
				return listUser.get(0);
			}*/
			User s = (User) sessionFactory.getCurrentSession().load(User.class, id);
			return s;
		}
		
		@SuppressWarnings("unchecked")
		public List<User> list() {
			
			/*List<User> listUser = (List<User>) 
			          sessionFactory.getCurrentSession()
					.createCriteria(User.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();*/
			List<User> listUser = (List<User>)sessionFactory.getCurrentSession().createCriteria(User.class).list();
			return listUser;
		}

public UserDAOImpl()
{}
				
		public boolean isValidUser(String email_id,String password) {
			
			/*String hql="from user where email_id='"+email_id+"'and password='"+password +"'";
			Query q= sessionFactory.getCurrentSession().createQuery(hql);
			List list= q.list();
			return (!list.isEmpty());*/
			return true;
			
		}
}
