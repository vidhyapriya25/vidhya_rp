package ss.DAO;


import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.Supplier;

@Repository("supplierDAO")

public class SupplierDAOImpl implements SupplierDAO {
	

		

		@Autowired
		private SessionFactory sessionFactory;


		public SupplierDAOImpl(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}



		
		public void saveOrUpdate(Supplier supplier) {
			sessionFactory.getCurrentSession().saveOrUpdate(supplier);
				
		}

		
		public void delete(String id) {
			Supplier supplier = new Supplier();
			supplier.setId(id);
			sessionFactory.getCurrentSession().delete(supplier);
		}

		
		public Supplier get(String id) {
			String hql = "from Supplier where id=" + "'"+ id +"'";
			//  from supplier where id = '101'
			Query query =  sessionFactory.getCurrentSession().createQuery(hql);
			List<Supplier> listSupplier = (List<Supplier>) query.list();
			
			if (listSupplier != null && !listSupplier.isEmpty()) {
				return listSupplier.get(0);
			}
			return null;
		}
		
		
		public List<Supplier> list() {
			@SuppressWarnings("unchecked")
			List<Supplier> listSupplier = (List<Supplier>) 
			          sessionFactory.getCurrentSession()
					.createCriteria(Supplier.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			return listSupplier;
		}



		public void saverOrUpdate(Supplier supplier) {
			// TODO Auto-generated method stub
			
		}
		
		

}
