package ss.DAO;

import java.util.List;



import ss.Model.Admin;


public interface AdminDAO {
	public List<Admin> list();
	public Admin get(String id);
	public void saverOrUpdate(Admin admin);
	public void delete(String id);
	public boolean isValidUser(String email_id, String password);

}
