package ss.controller;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ss.DAO.ProductDAO;
import ss.Model.Product;

@Controller

public class AdminController {
	static AnnotationConfigApplicationContext ct;
	static ProductDAO pr;
	
	static{
		ct=new AnnotationConfigApplicationContext();
		ct.scan("ss");
		ct.refresh();
		pr=(ProductDAO) ct.getBean("productDAO");
	}
	
	@ModelAttribute("obj1")
	public Product getObj()
	{
		return new Product();
	}
	
	@RequestMapping(value="/adminindex")
	public String adminindex()
	{
		return "admin_index";
	}
	
	@RequestMapping(value="/addproduct")
	public String addproduct1()
	{
		return "addproduct";
	}
	

	@RequestMapping(value="/saveProduct")
	public String adminproduct(@ModelAttribute("obj1")Product p)
	{
		pr.saveOrUpdate(p);
		return "redirect:/product";
	}
	
	@RequestMapping(value="/category")
	public String admincategory()
	{
		return "admincategory";
	}
	
	@RequestMapping(value="/supplier")
	public String adminsupplier()
	{
		return "adminsupplier";
	}
	
	@RequestMapping(value="/logout")
	public String logout()
	{
		return "logout";
	}
	@RequestMapping("/addcategory")
	public String addcategory()
	{
		return "addcategory";
	}
	
	@RequestMapping("/product")
	public ModelAndView addproduct()
	{
		ModelAndView mv=new ModelAndView("adminproduct");
		List<Product> l=pr.list1();
		if(!l.isEmpty())
				mv.addObject("data", l);
		return mv;
	}
	
	
	@RequestMapping("/addsupplier")
	public String addsupplier()
	{
		return "addsupplier";
	}
}
