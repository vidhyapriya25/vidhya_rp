package ss.DAO;

import java.util.List;

import ss.Model.Supplier;

public interface SupplierDAO {
	public List<Supplier> list();
	public Supplier get(String id);
	public void saverOrUpdate(Supplier supplier);
	public void delete(String id);

}
