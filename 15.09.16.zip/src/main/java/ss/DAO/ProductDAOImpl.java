package ss.DAO;

import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.Product;

@Repository("productDAO")


public class ProductDAOImpl implements ProductDAO {
	
		

		@Autowired
		private SessionFactory sessionFactory;





	
		public void saveOrUpdate(Product product) {
			sessionFactory.getCurrentSession().saveOrUpdate(product);
				
		}

		
		public void delete(String id) {
			Product product = new Product();
			product.setP_id(id);
			sessionFactory.getCurrentSession().delete(product);
		}

		
		public Product get(String id) {
			String hql = "from Product where p_id=" + "'"+ id +"'";
			//  from product where id = '101'
			//Query query =  sessionFactory.getCurrentSession().createQuery(hql);
			//List<Product> listProduct = (List<Product>) query.list();
			Product p=(Product)sessionFactory.getCurrentSession().load(Product.class, id)
;		/*	if (listProduct != null && !listProduct.isEmpty()) {
				return listProduct.get(0);
	
			return null;*/
			return p;
		}
		
		
		public List<Product> list1() {
			@SuppressWarnings("unchecked")
			List<Product> listProduct = (List<Product>)sessionFactory.getCurrentSession().createCriteria(Product.class).list();
			return listProduct;
		}



	
		
		


}
