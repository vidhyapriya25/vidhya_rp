package ss.DAO;


import java.util.List;




import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.Category;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO  {
	

	@Autowired
	private SessionFactory sessionFactory;


	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}



	
	public void saveOrUpdate(Category category) {
		sessionFactory.getCurrentSession().saveOrUpdate(category);
		System.out.println("data saved");
	}

	
	public void delete(String id) {
		Category category = new Category();
		category.setC_id(id);
		sessionFactory.getCurrentSession().delete(category);
	}

	
	public Category get(String id) {
		/*String hql = "from Category where c_name='"+ id +"'";
		//  from category where id = '101'
		Query query =  sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> listCategory = (List<Category>) query.list();*/
		Category c = (Category)sessionFactory.getCurrentSession().load(Category.class, id);
		/*if (listCategory != null && !listCategory.isEmpty()) {
			System.out.println(listCategory.get(0).getC_id());
			return listCategory.get(0);
		}*/
		return c;
	}
	

	public List<Category> list() {
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) 
		          sessionFactory.getCurrentSession()
				.createCriteria(Category.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listCategory;
	}

}

