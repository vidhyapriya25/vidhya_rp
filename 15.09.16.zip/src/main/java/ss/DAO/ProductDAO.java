package ss.DAO;

import java.util.List;

import ss.Model.Product;

public interface ProductDAO {

	public List<Product> list1();
	public Product get(String id);
	public void saveOrUpdate(Product product);
	public void delete(String id);
}
