package ss.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import ss.Model.Product;
import ss.service.ProductService;


@Controller
public class ProductController {
	
	@Autowired
	ProductService ps;
	
	ModelAndView m;
	
	
	@ModelAttribute("pobj")
	public Product getp(){
		return new Product();
	}
	
	
	@RequestMapping("/addProd")
	public ModelAndView addProd(@ModelAttribute("pobj")Product p){
		m = new  ModelAndView("pindex");
		ps.addProduct(p);
		return m;
	
	}
	
	@RequestMapping("/pinfo/{id}")
	public ModelAndView getProd(@PathVariable("id")int id){
		m = new ModelAndView("updateProduct");
		m.addObject("oldobj", ps.getProductId(id));
		return m;

	}
	
	
    @RequestMapping("/delProd/{id}")
	public ModelAndView delProd(@PathVariable("id")int id){
		m = new ModelAndView("pindex");
		ps.delProduct(id);
		return m;

     }
	
	@RequestMapping("/updProd")
	public ModelAndView updProd(@ModelAttribute("oldobj")Product p){
		m = new ModelAndView("pindex");
		ps.updProduct(p);
		return m;
	}

}
