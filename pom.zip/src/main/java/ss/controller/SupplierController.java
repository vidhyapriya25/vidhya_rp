package ss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import ss.Model.Supplier;
import ss.service.SupplierService;

@Controller
public class SupplierController {
	
	
	@Autowired
	SupplierService ss;
	
	ModelAndView m;
	
	
	@ModelAttribute("supobj")
	public Supplier getsup(){
		return new Supplier();
	}
	
	@RequestMapping("/viewsupl")
	public ModelAndView viewSupl(){
		m = new ModelAndView("");
		List<Supplier> l = ss.getAllSupplier();
		m.addObject("sall", l);
		return m;
	}

	@RequestMapping("/addsup")
	public ModelAndView addsup(@ModelAttribute("supobj")Supplier sup){
		m = new  ModelAndView("supindex");
		ss.addSupplier(sup);
		return m;
	
	}
	
	@RequestMapping(value="/add1",method=RequestMethod.POST)
	public ModelAndView addsup1(@ModelAttribute("supobj")Supplier s,BindingResult br){
		m = new ModelAndView();
		ss.addSupplier(s);
		return m;
	}
	
	@RequestMapping("/supinfo/{id}")
	public ModelAndView getsup(@PathVariable("id")int id){
		m = new ModelAndView("updateSupplier");
		m.addObject("oldobj", ss.getSupplierId(id));
		return m;

	}
	
	@RequestMapping("/delsup/{id}")
	public ModelAndView delsup(@PathVariable("id")int id){
		m = new ModelAndView("supindex");
		ss.delSupplier(id);
		return m;

     }
	
	@RequestMapping("/updsup")
	public ModelAndView updsup(@ModelAttribute("oldobj")Supplier sup){
		m = new ModelAndView("supindex");
		ss.updSupplier(sup);
		return m;
	}


}
