package ss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ss.Model.Category;
import ss.service.CategoryService;

@Controller
public class CategoryController {
	
	
	@Autowired
	CategoryService cs1;
	
	
	ModelAndView m;
	
	@ModelAttribute("catobj")
	public Category getcat(){
		return new Category();

	}
	
	@RequestMapping("/addcat")
	public ModelAndView addcat(@ModelAttribute("catobj")Category cat){
		m = new  ModelAndView("catindex");
		cs1.addCategory(cat);
		return m;
	
	}
	
	@RequestMapping("/catinfo/{id}")
	public ModelAndView getCat(@PathVariable("id")int id){
		m = new ModelAndView("updateCategory");
		m.addObject("oldobj", cs1.getCategoryId(id));
		return m;

	}
	
	@RequestMapping("/delcat/{id}")
	public ModelAndView delcat(@PathVariable("id")int id){
		m = new ModelAndView("catindex");
		cs1.delCategory(id);
		return m;

     }
	
	@RequestMapping("/updcat")
	public ModelAndView updcat(@ModelAttribute("oldobj")Category cat){
		m = new ModelAndView("catindex");
		cs1.updCategory(cat);
		return m;
	}
	
	@RequestMapping("")
	public ModelAndView ViewAllCats(){
		m = new ModelAndView();
		List<Category> l = cs1.getAllCategory();
		m.addObject("call", l);
		return m;
	
	}


}
	

