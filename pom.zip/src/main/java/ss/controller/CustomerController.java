package ss.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ss.Model.Customer;
import ss.service.CustomerService;

@Controller
public class CustomerController {
	
	
	@Autowired
	CustomerService cs;
	
	ModelAndView m;
	
	
	@ModelAttribute("cobj")
	public Customer getc(){
		return new Customer();
	}
	
	@RequestMapping("/addcust")
	public ModelAndView addCust(@ModelAttribute("cobj")Customer c){
		m = new ModelAndView("cindex");
		cs.addCustomer(c);
		return m;
	}
	
	@RequestMapping("/cinfo/{id}")
	public ModelAndView getCust(@PathVariable("id")int id){
		m = new ModelAndView("updateCustomer");
		m.addObject("oldobj", cs.getCustomerId(id));
		return m;
	}
	
	@RequestMapping("/delcust/{id}")
	public ModelAndView delCust(@PathVariable("id")int id){
		m = new ModelAndView("cindex");
		cs.delCustomer(id);
		return m;
	}
	
	@RequestMapping("/updcust")
	public ModelAndView updCust(@ModelAttribute("oldobj")Customer c){
		m = new ModelAndView("cindex");
		cs.updCustomer(c);
		return m;
	}
	
	
	

}
