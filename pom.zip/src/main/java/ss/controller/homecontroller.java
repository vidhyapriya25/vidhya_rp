package ss.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class homecontroller {
	

	@RequestMapping("/")
	public String goh(){
		return"index";
	}
	
	
	@RequestMapping("/login")
	public String goh1(){
		return"login";
	}
	
	@RequestMapping("/register")
	public String goh2(){
		return"register";


}
	
}