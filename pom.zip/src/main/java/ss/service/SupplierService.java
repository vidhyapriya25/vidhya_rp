package ss.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ss.Dao.SupplierDAO;
import ss.Model.Supplier;

@Service
public class SupplierService {
	
	@Autowired
	SupplierDAO sd;
	
	public void   addSupplier(Supplier s){
    	sd.addSupplier(s);
    }
    
    public void delSupplier(int id){
    	sd.delSupplier(id);
    }
    
    public void updSupplier(Supplier s){
    	sd.updSupplier(s);
    }
    
    public Supplier getSupplierId(int id){
    	return sd.getSupplierId(id);
    }
    
    public List<Supplier> getAllSupplier(){
    	return sd.getAllSupplier();
    }
    
}
