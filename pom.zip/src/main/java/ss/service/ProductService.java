package ss.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ss.Dao.ProductDAO;
import ss.Model.Product;

@Service
public class ProductService {
	
	@Autowired
	ProductDAO pd;
	
	
	public void   addProduct(Product p){
    	pd.addProduct(p);
    }
    
    public void delProduct(int id){
    	pd.delProduct(id);
    }
    
    public void updProduct(Product p){
    	pd.updProduct(p);
    }
    
    public Product getProductId(int id){
    	return pd.getProductId(id);
    }
    
    public List<Product> getAllProduct(){
    	return pd.getAllProducts();
    }

}
