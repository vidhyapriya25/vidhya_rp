package ss.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ss.Dao.CategoryDAO;
import ss.Model.Category;

@Service
public class CategoryService {
	
	
	@Autowired
	CategoryDAO cd;
	
	public void   addCategory(Category c){
    	cd.addCategory(c);
    }
    
    public void delCategory(int id){
    	cd.delCategory(id);
    }
    
    public void updCategory(Category c){
    	cd.updCategory(c);
    }
    
    public Category getCategoryId(int id){
    	return cd.getCategoryId(id);
    }
    
    public List<Category> getAllCategory(){
    	return cd.getAllCategory();
    }



}
