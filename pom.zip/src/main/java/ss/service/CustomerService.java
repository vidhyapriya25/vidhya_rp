package ss.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ss.Dao.CustomerDAO;
import ss.Model.Customer;

@Service
public class CustomerService {
	
	@Autowired
	CustomerDAO cd;
    public void   addCustomer(Customer c){
    	cd.addCustomer(c);
    }
    
    public void delCustomer(int id){
    	cd.delCustomer(id);
    }
    
    public void updCustomer(Customer c){
    	cd.updCustomer(c);
    }
    
    public Customer getCustomerId(int id){
    	return cd.getCustomerId(id);
    }
    
    public List<Customer> getAllCustomer(){
    	return cd.getAllCustomers();
    }
}
