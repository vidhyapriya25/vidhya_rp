package ss.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.Category;



@Repository
public class CategoryDAO {
	
	
	@Autowired
	SessionFactory sf;
	
	
	Session s;
	Transaction t;
	Category x;
	
	
    public void addCategory(Category c){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
	    s.save(c);
		t.commit();
		
	}
	
	public void delCategory(int id){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Category)s.load(Category.class,id);
		s.delete(x);
		t.commit();
		
	}
	
	public void updCategory(Category c){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Category)s.load(Category.class,c.getCatid());
		x.setCatname(c.getCatname());
        s.saveOrUpdate(x);
		t.commit();
		
	}
	
	public Category getCategoryId(int Id){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Category)s.load(Category.class,Id);
		t.commit();
		
		return x;
		
	}
	
	@SuppressWarnings("unchecked")
    public List<Category> getAllCategory(){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		List<Category> l= s.createCriteria(Category.class).list();
		t.commit();
		
		return l;
	
	}

}
