package ss.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import ss.Model.Supplier;

@Repository
public class SupplierDAO {
	
	
	
	@Autowired
	SessionFactory sf;
	
	
	Session s;
	Transaction t;
	Supplier x;

	
    public void addSupplier(Supplier sup){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
	    s.save(sup);
		t.commit();
		
	}
	
	public void delSupplier(int id){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Supplier)s.load(Supplier.class,id);
		s.delete(x);
		t.commit();
		
	}
	
	public void updSupplier(Supplier sup){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Supplier)s.load(Supplier.class,sup.getSupid());
		x.setSupname(sup.getSupname());
        s.saveOrUpdate(x);
		t.commit();
		
	}
	
	public Supplier getSupplierId(int Id){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Supplier)s.load(Supplier.class,Id);
		t.commit();
		
		return x;
		
	}
	
   @SuppressWarnings("unchecked")
   public List<Supplier> getAllSupplier(){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		List<Supplier> l= s.createCriteria(Supplier.class).list();
		t.commit();
		
		return l;
	
	}
	
	
	
}
