package ss.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ss.Model.Product;

@Repository
public class ProductDAO {
	
	
	@Autowired
	SessionFactory sf;
	
	
	Session s;
	Transaction t;
	Product x;
	
	
	public void addProduct(Product p){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
	    s.save(p);
		t.commit();
		
	}
	
	public void delProduct(int id){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Product)s.load(Product.class,id);
		s.delete(x);
		t.commit();
		
	}
	
	public void updProduct(Product p){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Product)s.load(Product.class,p.getPid());
		x.setPname(p.getPname());
		x.setPcat(p.getPcat());
		x.setPprice(p.getPprice());
		s.saveOrUpdate(x);
		t.commit();
		
	}
	
	public Product getProductId(int Id){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		x=(Product)s.load(Product.class,Id);
		t.commit();
		
		return x;
		
	}
	
	@SuppressWarnings("unchecked")
	public List<Product> getAllProducts(){
		
		s=sf.getCurrentSession();
		t=s.beginTransaction();
		List<Product> l= s.createCriteria(Product.class).list();
		t.commit();
		
		return l;
	
   }
}
