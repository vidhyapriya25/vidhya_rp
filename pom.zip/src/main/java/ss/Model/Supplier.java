package ss.Model;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Table
@Entity
@Component


public class Supplier {
	
	@Id
	@GeneratedValue
	private int supid;
	@Column
	private String  supname;
    
	
	public int getSupid(){
		return supid;
	}
	
	public void setSupid(int supid){
		this.supid = supid;
	}
	public String getSupname() {
		return supname;
	}
	public void setSupname(String supname) {
		this.supname = supname;
	}
	
}
